<?php
require "../config.php";
header('Content-Type: application/json');
if (!isset($_SESSION['user_id'])) { http_response_code(401); echo '[]'; exit; }
$stmt=$pdo->prepare("SELECT id,pengirim,pesan,mode,created_at FROM messages WHERE user_id=? ORDER BY id ASC");
$stmt->execute([$_SESSION['user_id']]);
echo json_encode($stmt->fetchAll(), JSON_UNESCAPED_UNICODE);
