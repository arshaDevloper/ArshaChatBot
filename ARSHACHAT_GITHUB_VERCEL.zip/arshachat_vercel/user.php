<?php
require "config.php";
if (!isset($_SESSION['user_id'])) { header("Location:index.php"); exit; }
$stmt=$pdo->prepare("SELECT * FROM users WHERE id=?"); $stmt->execute([$_SESSION['user_id']]); $me=$stmt->fetch();
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ARSHACHAT</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#0f1113;color:#fff;font-family:Arial;height:100vh;display:flex;flex-direction:column}
.top{height:58px;border-bottom:1px solid #292929;display:flex;align-items:center;padding:0 18px;font-weight:bold}.top a{margin-left:auto;color:#aaa;text-decoration:none}
.chat{flex:1;overflow:auto;padding:20px;max-width:850px;width:100%;margin:auto}.row{display:flex;margin:10px 0}.row.user{justify-content:flex-end}.bubble{max-width:78%;padding:10px 14px;border-radius:17px;white-space:pre-wrap}.mine{background:#303030}.other{background:#173d2a}.meta{font-size:10px;color:#aaa;margin-bottom:4px}
.input{padding:12px;border-top:1px solid #292929}.box{max-width:850px;margin:auto;display:flex;background:#242424;border:1px solid #444;border-radius:18px;padding:7px}
textarea{flex:1;background:transparent;color:#fff;border:0;outline:0;resize:none;padding:10px;font-size:15px}.send{width:44px;border:0;border-radius:50%;background:#fff;color:#111}
.empty{color:#888;text-align:center;margin-top:35vh}
</style>
</head>
<body>
<div class="top">ARSHACHAT <span style="margin-left:12px;color:#888;font-size:12px"><?=htmlspecialchars($me['nama'])?></span><a href="logout.php">Keluar</a></div>
<div class="chat" id="chat"><div class="empty">Halo <?=htmlspecialchars($me['nama'])?> 👋<br>Mulai percakapan.</div></div>
<div class="input"><div class="box"><textarea id="msg" placeholder="Ketik pesan..." rows="1" onkeydown="enterSend(event)"></textarea><button class="send" onclick="send()">➤</button></div></div>
<script>
let lastId=0;
async function load(){
 const r=await fetch('api/messages.php'); const data=await r.json();
 const chat=document.getElementById('chat');
 if(data.length) chat.innerHTML='';
 for(const m of data){
   if(m.id<=lastId) continue;
   lastId=Number(m.id);
   const row=document.createElement('div'); row.className='row '+(m.pengirim==='user'?'user':'');
   const b=document.createElement('div'); b.className='bubble '+(m.pengirim==='user'?'mine':'other');
   b.innerHTML='<div class="meta">'+(m.pengirim==='user'?'Kamu':(m.pengirim==='ai'?'AI':'Admin'))+'</div>';
   const c=document.createElement('div'); c.textContent=m.pesan; b.appendChild(c); row.appendChild(b); chat.appendChild(row);
 }
 chat.scrollTop=chat.scrollHeight;
}
async function send(){
 const x=document.getElementById('msg'), v=x.value.trim(); if(!v)return;
 x.value='';
 await fetch('api/send.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pesan:v})});
 load();
}
function enterSend(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send()}}
load(); setInterval(load,2000);
</script>
</body></html>
