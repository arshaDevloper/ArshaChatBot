<?php
require "../config.php";

$ADMIN_USER = getenv('ADMIN_USER') ?: 'admin';
$ADMIN_PASS = getenv('ADMIN_PASS') ?: 'admin123';
$username = (string)($_POST['username'] ?? '');
$password = (string)($_POST['password'] ?? '');

if (hash_equals($ADMIN_USER, $username) && hash_equals($ADMIN_PASS, $password)) {
    session_regenerate_id(true);
    $_SESSION['admin'] = true;
    header('Location: ../admin.php');
    exit;
}
header('Location: ../admin_login.php?error=' . urlencode('Username/password salah.'));
