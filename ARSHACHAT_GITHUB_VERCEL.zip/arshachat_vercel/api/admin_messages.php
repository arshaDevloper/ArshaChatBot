<?php
require "../config.php"; header('Content-Type: application/json');
if(empty($_SESSION['admin'])){http_response_code(403);echo'[]';exit;}
$id=(int)($_GET['user_id']??0);
$stmt=$pdo->prepare("SELECT id,pengirim,pesan,mode,created_at FROM messages WHERE user_id=? ORDER BY id ASC");
$stmt->execute([$id]); echo json_encode($stmt->fetchAll(),JSON_UNESCAPED_UNICODE);
