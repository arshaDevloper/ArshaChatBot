<?php
require "config.php";
if (isset($_SESSION['user_id'])) {
    header("Location: user.php");
    exit;
}
$error = $_GET['error'] ?? '';
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ARSHACHAT - Login</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#111;color:#fff;font-family:Arial;display:grid;place-items:center;min-height:100vh}
.card{width:min(400px,92%);background:#1d1d1d;border:1px solid #333;border-radius:18px;padding:25px}
h1{margin-top:0}.muted{color:#999}.error{background:#4a1818;padding:10px;border-radius:9px;margin-bottom:12px}
input,button{width:100%;padding:13px;border-radius:10px;border:1px solid #444;background:#292929;color:#fff;margin:6px 0;font-size:15px}
button{background:#fff;color:#111;border:0;font-weight:bold;cursor:pointer}.link{color:#8ab4ff;text-decoration:none}
</style>
</head>
<body>
<div class="card">
<h1>ARSHACHAT</h1>
<p class="muted">Masuk ke akun kamu</p>
<?php if($error): ?><div class="error"><?=htmlspecialchars($error)?></div><?php endif; ?>
<form action="api/login.php" method="post">
<input name="login" placeholder="Email atau nomor HP" required>
<input name="password" type="password" placeholder="Password" required>
<button>Masuk</button>
</form>
<p>Belum punya akun? <a class="link" href="register.php">Daftar</a></p>
<p><a class="link" href="admin_login.php">Login Admin</a></p>
</div>
</body>
</html>
