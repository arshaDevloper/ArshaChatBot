<?php
require "../config.php";

$login = trim($_POST['login'] ?? '');
$password = $_POST['password'] ?? '';

$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? OR nomor_hp = ? LIMIT 1");
$stmt->execute([$login,$login]);
$u = $stmt->fetch();

if (!$u || !password_verify($password,$u['password'])) {
    header("Location: ../index.php?error=" . urlencode("Login salah."));
    exit;
}

$_SESSION['user_id'] = $u['id'];
header("Location: ../user.php");
