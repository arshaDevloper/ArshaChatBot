<?php
/* ARSHACHAT - konfigurasi yang cocok untuk deployment Vercel + PHP/FrankenPHP. */

$host = getenv('DB_HOST') ?: 'localhost';
$port = getenv('DB_PORT') ?: '3306';
$db   = getenv('DB_NAME') ?: 'arshachat';
$user = getenv('DB_USER') ?: 'root';
$pass = getenv('DB_PASS') ?: '';

try {
    $pdo = new PDO(
        "mysql:host={$host};port={$port};dbname={$db};charset=utf8mb4",
        $user,
        $pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    exit('Database belum tersambung. Periksa Environment Variables DB_HOST, DB_PORT, DB_NAME, DB_USER, dan DB_PASS di Vercel.');
}

/* Session disimpan di database agar tidak bergantung pada filesystem instance Vercel. */
class ArshaDbSessionHandler implements SessionHandlerInterface {
    private PDO $pdo;
    public function __construct(PDO $pdo) { $this->pdo = $pdo; }
    public function open(string $path, string $name): bool { return true; }
    public function close(): bool { return true; }
    public function read(string $id): string {
        $q = $this->pdo->prepare('SELECT data FROM sessions WHERE id = ? AND expires_at > NOW() LIMIT 1');
        $q->execute([$id]);
        return (string)($q->fetchColumn() ?: '');
    }
    public function write(string $id, string $data): bool {
        $ttl = (int)(getenv('SESSION_LIFETIME') ?: 86400 * 7);
        $q = $this->pdo->prepare('INSERT INTO sessions (id, data, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL ? SECOND)) ON DUPLICATE KEY UPDATE data = VALUES(data), expires_at = VALUES(expires_at)');
        return $q->execute([$id, $data, $ttl]);
    }
    public function destroy(string $id): bool {
        $q = $this->pdo->prepare('DELETE FROM sessions WHERE id = ?');
        return $q->execute([$id]);
    }
    public function gc(int $max_lifetime): int|false {
        $q = $this->pdo->prepare('DELETE FROM sessions WHERE expires_at < NOW()');
        $q->execute();
        return $q->rowCount();
    }
}

session_set_save_handler(new ArshaDbSessionHandler($pdo), true);
session_name('ARSHACHAT_SESSION');
session_set_cookie_params([
    'lifetime' => 60 * 60 * 24 * 7,
    'path' => '/',
    'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

function fotoDataUri(?string $foto): ?string {
    if (!$foto) return null;
    return str_starts_with($foto, 'data:image/') ? $foto : null;
}
