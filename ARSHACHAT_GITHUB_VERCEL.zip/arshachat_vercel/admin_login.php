<?php
require "config.php";

if (!empty($_SESSION['admin'])) {
    header("Location: admin.php");
    exit;
}

$error = $_GET['error'] ?? '';
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login Admin - ARSHACHAT</title>
<style>
*{box-sizing:border-box}
body{
    margin:0;
    min-height:100vh;
    background:#0b0d0f;
    color:#fff;
    font-family:Arial,sans-serif;
    display:flex;
    align-items:center;
    justify-content:center;
}
.login{
    width:min(390px,92%);
    background:#17191c;
    border:1px solid #303338;
    border-radius:22px;
    padding:30px;
    box-shadow:0 20px 60px #0008;
}
.logo{
    width:70px;
    height:70px;
    border-radius:50%;
    background:#26313b;
    display:grid;
    place-items:center;
    margin:0 auto 18px;
    font-size:30px;
}
h1{text-align:center;margin:0 0 7px;font-size:25px}
.sub{text-align:center;color:#8f969e;margin:0 0 25px;font-size:14px}
label{display:block;color:#bbb;font-size:13px;margin:14px 0 7px}
input{
    width:100%;
    padding:14px;
    border-radius:12px;
    border:1px solid #3b3f44;
    background:#24272b;
    color:#fff;
    outline:none;
    font-size:15px;
}
input:focus{border-color:#718096}
button{
    width:100%;
    margin-top:20px;
    padding:14px;
    border:0;
    border-radius:12px;
    background:#fff;
    color:#111;
    font-weight:bold;
    cursor:pointer;
}
.error{
    background:#4b1c1c;
    border:1px solid #713333;
    padding:11px;
    border-radius:10px;
    color:#ffb5b5;
    font-size:13px;
}
.security{
    text-align:center;
    color:#666;
    font-size:11px;
    margin-top:20px;
}
</style>
</head>
<body>
<div class="login">
    <div class="logo">🛠️</div>
    <h1>ARSHACHAT ADMIN</h1>
    <p class="sub">Masuk ke pusat pesan kamu</p>

    <?php if($error): ?>
        <div class="error"><?=htmlspecialchars($error)?></div>
    <?php endif; ?>

    <form method="post" action="api/admin_login.php">
        <label>Username Admin</label>
        <input name="username" autocomplete="username" placeholder="Masukkan username" required>

        <label>Password</label>
        <input name="password" type="password" autocomplete="current-password" placeholder="Masukkan password" required>

        <button type="submit">Masuk ke Dashboard</button>
    </form>

    <div class="security">🔒 Halaman khusus pemilik ARSHACHAT</div>
</div>
</body>
</html>
