<?php
require "../config.php";
header('Content-Type: application/json');
if (!isset($_SESSION['user_id'])) { http_response_code(401); exit; }
$data=json_decode(file_get_contents('php://input'),true);
$pesan=trim($data['pesan'] ?? '');
if($pesan===''){echo json_encode(['ok'=>false]);exit;}
$stmt=$pdo->prepare("INSERT INTO messages(user_id,pengirim,pesan,mode) VALUES(?,?,?,'manual')");
$stmt->execute([$_SESSION['user_id'],'user',$pesan]);
echo json_encode(['ok'=>true]);
