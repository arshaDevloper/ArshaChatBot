<?php
require "../config.php"; header('Content-Type: application/json');
if(empty($_SESSION['admin'])){http_response_code(403);exit;}
$data=json_decode(file_get_contents('php://input'),true);
$uid=(int)($data['user_id']??0);$pesan=trim($data['pesan']??'');$mode=($data['mode']??'manual')==='ai'?'ai':'manual';
if(!$uid||$pesan===''){echo json_encode(['ok'=>false]);exit;}
$stmt=$pdo->prepare("INSERT INTO messages(user_id,pengirim,pesan,mode) VALUES(?,?,?,?)");
$stmt->execute([$uid,$mode==='ai'?'ai':'admin',$pesan,$mode]);
echo json_encode(['ok'=>true]);
