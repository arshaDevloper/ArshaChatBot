<?php
$error = $_GET['error'] ?? '';
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Daftar - ARSHACHAT</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#111;color:#fff;font-family:Arial;display:grid;place-items:center;min-height:100vh}
.card{width:min(420px,92%);background:#1d1d1d;border:1px solid #333;border-radius:18px;padding:25px}
input,button{width:100%;padding:13px;border-radius:10px;border:1px solid #444;background:#292929;color:#fff;margin:6px 0;font-size:15px}
button{background:#fff;color:#111;border:0;font-weight:bold}.error{background:#4a1818;padding:10px;border-radius:9px}.muted{color:#999}
a{color:#8ab4ff}
</style>
</head>
<body>
<div class="card">
<h1>Buat akun</h1><p class="muted">Nama dan foto profil akan terlihat di dashboard chat. Foto maksimal 1 MB.</p>
<?php if($error): ?><div class="error"><?=htmlspecialchars($error)?></div><?php endif; ?>
<form action="api/register.php" method="post" enctype="multipart/form-data">
<input name="nama" placeholder="Nama" required>
<input name="email" type="email" placeholder="Email (opsional)">
<input name="nomor_hp" placeholder="Nomor HP (opsional)">
<input name="password" type="password" placeholder="Password" required>
<input name="foto" type="file" accept="image/*">
<button>Daftar</button>
</form>
<p><a href="index.php">Kembali ke login</a></p>
</div>
</body>
</html>
