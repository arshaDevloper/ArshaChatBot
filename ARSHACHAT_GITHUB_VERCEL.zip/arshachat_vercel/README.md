# ARSHACHAT — GitHub → Vercel

Versi ini mempertahankan alur ARSHACHAT user/admin berbasis PHP + MySQL, tetapi disiapkan untuk deployment Vercel menggunakan `Dockerfile.vercel` dan FrankenPHP.

## Fitur
- Login user dengan email atau nomor HP
- Registrasi user
- Foto profil disimpan sebagai data di database agar tidak bergantung pada filesystem Vercel
- Chat user ↔ admin tersimpan di database
- Dashboard admin bergaya WhatsApp
- Pilihan mode `Saya menjawab` atau `AI` seperti versi sebelumnya
- Polling chat setiap 2 detik
- Session login disimpan di database
- Konfigurasi database dan admin lewat Environment Variables

## Database
Import `database.sql` ke MySQL/MariaDB yang bisa diakses dari internet.

Jangan menjalankan `DROP DATABASE` pada database produksi.

## Environment Variables Vercel
Set:
- `DB_HOST`
- `DB_PORT`
- `DB_NAME`
- `DB_USER`
- `DB_PASS`
- `ADMIN_USER`
- `ADMIN_PASS`
- `SESSION_LIFETIME` (opsional)

## Deploy
1. Upload repository ini ke GitHub.
2. Import repository tersebut ke Vercel.
3. Vercel akan menggunakan `Dockerfile.vercel`.
4. Isi Environment Variables.
5. Deploy.
6. Setiap `git push` berikutnya akan membuat deployment baru jika Git integration aktif.

## Catatan
- Database tidak berada di dalam Vercel. Gunakan MySQL/MariaDB eksternal.
- Folder `uploads` tidak dipakai lagi untuk foto profil karena filesystem deployment tidak dijadikan penyimpanan permanen.
- Untuk production, ganti password admin default dan gunakan database dengan SSL/TLS jika penyedia database mengharuskannya.
