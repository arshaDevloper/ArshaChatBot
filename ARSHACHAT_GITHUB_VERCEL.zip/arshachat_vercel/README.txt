ARSHACHAT - SISTEM CHAT USER + ADMIN

1. Install PHP + MySQL.
2. Buat database dengan menjalankan database.sql.
3. Edit config.php jika username/password MySQL berbeda.
4. Pastikan folder uploads bisa ditulis server.
5. Buka index.php untuk user.
6. Buka admin_login.php untuk dashboard kamu.

LOGIN ADMIN DEFAULT:
username: admin
password: admin123

WAJIB ganti username/password admin di api/admin_login.php sebelum dipakai sungguhan.

CATATAN:
- Sistem ini menyimpan pesan di MySQL.
- Dashboard menggunakan polling 2 detik agar pesan baru muncul otomatis.
- Mode "Saya" menyimpan balasan sebagai admin.
- Mode "AI" pada dashboard ini adalah pilihan mode pesan; mesin AI sungguhan/API dapat ditambahkan pada tahap berikutnya.
- Untuk penggunaan online sungguhan, gunakan HTTPS dan konfigurasi keamanan server yang benar.
