<?php
require "../config.php";

$nama = trim($_POST['nama'] ?? '');
$email = trim($_POST['email'] ?? '') ?: null;
$nomor = trim($_POST['nomor_hp'] ?? '') ?: null;
$password = $_POST['password'] ?? '';

if ($nama === '' || $password === '') exit('Data belum lengkap.');
if (!$email && !$nomor) exit('Isi email atau nomor HP.');

$foto = null;
if (!empty($_FILES['foto']['name']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
    if ($_FILES['foto']['size'] > 1024 * 1024) exit('Ukuran foto maksimal 1 MB.');
    $tmp = $_FILES['foto']['tmp_name'];
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($tmp);
    $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'];
    if (!isset($allowed[$mime])) exit('Format foto tidak didukung.');
    $raw = file_get_contents($tmp);
    $foto = 'data:' . $mime . ';base64,' . base64_encode($raw);
}

try {
    $stmt = $pdo->prepare('INSERT INTO users (nama,email,nomor_hp,password,foto_profil) VALUES (?,?,?,?,?)');
    $stmt->execute([$nama,$email,$nomor,password_hash($password,PASSWORD_DEFAULT),$foto]);
    header('Location: ../index.php');
} catch (PDOException $e) {
    header('Location: ../register.php?error=' . urlencode('Email/nomor HP sudah digunakan.'));
}
