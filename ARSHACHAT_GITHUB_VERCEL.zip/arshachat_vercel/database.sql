CREATE DATABASE IF NOT EXISTS arshachat CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE arshachat;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    email VARCHAR(190) UNIQUE NULL,
    nomor_hp VARCHAR(30) UNIQUE NULL,
    password VARCHAR(255) NOT NULL,
    foto_profil LONGTEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS messages (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    pengirim ENUM('user','admin','ai') NOT NULL,
    pesan TEXT NOT NULL,
    mode ENUM('ai','manual') DEFAULT 'manual',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_chat (user_id, id)
);

CREATE TABLE IF NOT EXISTS sessions (
    id VARCHAR(128) PRIMARY KEY,
    data MEDIUMTEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    INDEX idx_sessions_expiry (expires_at)
);
